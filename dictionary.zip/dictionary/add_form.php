
<style type="tExt/css">
#dis{
	display:none;
}
</style>


	
    
    <div id="dis">
    <!-- here message will be displayed -->
	</div>
        
 	
	 <form method='post' id='emp-SaveForm' action="#">
 
    <table class='table table-bordered'>
 
        <tr>
            <td>English</td>
            <td><input type='tExt' name='english' class='form-control' placeholder='Ex : car' required /></td>
        </tr>
 
        <tr>
            <td>english type</td>
            <td><input type='tExt' name='wordtype' class='form-control' placeholder='Ex : noun' required></td>
        </tr>
 
        <tr>
            <td>Definition</td>
            <td><input type='tExt' name='definition' class='form-control' placeholder='Ex : means of transportation' required></td>
        </tr>
		
		<tr>
            <td>Swedish</td>
            <td><input type='tExt' name='swedish' class='form-control' placeholder='Ex : bil' required></td>
        </tr>
 
        <tr>
            <td colspan="2">
            <button type="submit" class="btn btn-primary" name="btn-save" id="btn-save">
    		<span class="glyphicon glyphicon-plus"></span> Save this Record
			</button>  
            </td>
        </tr>
 
    </table>
</form>
     
